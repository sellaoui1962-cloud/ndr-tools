package com.ndr.tools

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View

/** Simple horizontal slider 0..100 (left = 0). Drawn by hand so it needs no theme. */
class SliderView(
    ctx: Context,
    private var value: Int,
    private val onChange: (Int) -> Unit
) : View(ctx) {

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        trackPaint.color = 0xFF2A3145.toInt()
        thumbPaint.color = Color.WHITE
    }

    fun set(v: Int) {
        value = v.coerceIn(0, 100)
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val h = height.toFloat()
        val w = width.toFloat()
        val pad = h / 2f
        val cy = h / 2f
        val tr = h * 0.14f
        val x = pad + (w - 2 * pad) * value / 100f
        c.drawRoundRect(pad, cy - tr, w - pad, cy + tr, tr, tr, trackPaint)
        fillPaint.shader = LinearGradient(
            pad, 0f, w - pad, 0f, 0xFF00C6FF.toInt(), 0xFF4F6BFF.toInt(), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(pad, cy - tr, x, cy + tr, tr, tr, fillPaint)
        c.drawCircle(x, cy, h * 0.40f, thumbPaint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val pad = height / 2f
                val span = (width - 2 * pad).coerceAtLeast(1f)
                val f = ((e.x - pad) / span).coerceIn(0f, 1f)
                value = (f * 100).toInt()
                invalidate()
                onChange(value)
            }
        }
        return true
    }
}
