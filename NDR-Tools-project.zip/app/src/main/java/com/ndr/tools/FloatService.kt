package com.ndr.tools

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

/**
 * NDR TOOLS - a floating bubble that works on top of ANY keyboard.
 * It is an accessibility service: it draws overlay windows, reads / writes the focused
 * text field, taps the screen for the auto-clicker and reads emojis aloud.
 */
class FloatService : AccessibilityService() {

    // ------------------------------------------------------------ palette
    private val cPanel = 0xF2101524.toInt()
    private val cRow = 0xFF131A2B.toInt()
    private val cRowOn = 0xFF1A2650.toInt()
    private val cBorder = 0xFF4A5BFF.toInt()
    private val cBorderSoft = 0x553D5BFF
    private val cBlue = 0xFF4D8DFF.toInt()
    private val cViolet = 0xFFB07CFF.toInt()
    private val cMuted = 0xFF8C96A8.toInt()
    private val cText = 0xFFE8ECF4.toInt()
    private val cOff = 0xFF3A4150.toInt()
    private val cGreen = 0xFF2ED47A.toInt()
    private val cRed = 0xFFFF5C6C.toInt()

    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT

    // ------------------------------------------------------------ state
    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())

    private var bubble: TextView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var panel: FrameLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var target: View? = null
    private var targetLp: WindowManager.LayoutParams? = null
    private var card: FrameLayout? = null
    private var cardLp: WindowManager.LayoutParams? = null
    private var runCountTv: TextView? = null
    private var runBar: View? = null

    private enum class Mode { NORMAL, SETUP, RUNNING }

    private var mode = Mode.NORMAL

    private var lastEditable: AccessibilityNodeInfo? = null
    private var undoText: String? = null
    private var lastSet: String? = null

    private val selectedCats = linkedSetOf<String>()
    private val wilayaIdx = HashMap<Char, Int>()

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ttsPending: String? = null

    private var clickX = 0f
    private var clickY = 0f
    private var clicksDone = 0
    private var clicksTotal = 300

    private val catMeta = listOf(
        Triple("boy", "ولد", "♂"),
        Triple("girl", "بنت", "♀"),
        Triple("thing", "جماد", "📦"),
        Triple("animal", "حيوان", "🐾"),
        Triple("capital", "عاصمة", "🏛"),
        Triple("country", "دولة", "🌐"),
        Triple("plant", "نبات", "🌿")
    )

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "bubble_on") {
            handler.post {
                if (prefs.getBoolean("bubble_on", true)) showBubble() else hideAll()
            }
        }
    }

    // ------------------------------------------------------------ lifecycle
    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = Prefs.get(this)
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        if (prefs.getBoolean("bubble_on", true)) showBubble()
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!::wm.isInitialized) return
        closePanel()
        val b = bubble
        val lp = bubbleLp
        if (b != null && lp != null) {
            clampTo(lp)
            try { wm.updateViewLayout(b, lp) } catch (e: Exception) { }
        }
    }

    private fun cleanup() {
        handler.removeCallbacksAndMessages(null)
        if (::wm.isInitialized) hideAll()
        if (::prefs.isInitialized) prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        tts?.shutdown()
        tts = null
        ttsReady = false
    }

    private fun hideAll() {
        stopClicking(false)
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        bubble = null
        bubbleLp = null
    }

    // ------------------------------------------------------------ small helpers
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun sw(): Int = resources.displayMetrics.widthPixels
    private fun sh(): Int = resources.displayMetrics.heightPixels

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun buzz(v: View) {
        if (prefs.getBoolean("haptic", true)) v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
    }

    private fun solid(fill: Int, r: Int, stroke: Int = 0, strokeColor: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = dp(r).toFloat()
        if (stroke > 0) g.setStroke(stroke, strokeColor)
        return g
    }

    private fun rowBg(): GradientDrawable = solid(cRow, 12, dp(1), cBorderSoft)

    private fun gradBg(r: Int): GradientDrawable {
        val g = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(0xFF1F3FBF.toInt(), 0xFF5B3FE0.toInt())
        )
        g.cornerRadius = dp(r).toFloat()
        g.setStroke(dp(1), cBorder)
        return g
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    private fun llp(w: Int, h: Int, weight: Float = 0f, m: Int = 0): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(w, h, weight)
        l.setMargins(dp(m), dp(m), dp(m), dp(m))
        return l
    }

    private fun vcol(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        return c
    }

    private fun hrow(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        return r
    }

    private fun divider(): View {
        val v = View(this)
        v.setBackgroundColor(0x2AFFFFFF)
        val lp = LinearLayout.LayoutParams(MATCH, dp(1))
        lp.setMargins(0, dp(6), 0, dp(8))
        v.layoutParams = lp
        return v
    }

    private fun primaryBtn(text: String, click: () -> Unit): TextView {
        val t = label(text, 15f, Color.WHITE, true)
        t.gravity = Gravity.CENTER
        t.background = gradBg(14)
        t.setOnClickListener { buzz(it); click() }
        return t
    }

    private fun outlineBtn(text: String, color: Int, click: () -> Unit): TextView {
        val t = label(text, 14f, color, false)
        t.gravity = Gravity.CENTER
        t.background = solid(cRow, 12, dp(1), if (color == cRed) cRed else cBorderSoft)
        t.setOnClickListener { buzz(it); click() }
        return t
    }

    private fun iconBtn(text: String, click: () -> Unit): TextView {
        val t = label(text, 22f, Color.WHITE, false)
        t.gravity = Gravity.CENTER
        t.setOnClickListener { buzz(it); click() }
        return t
    }

    private fun toggleView(on: Boolean): FrameLayout {
        val f = FrameLayout(this)
        f.background = solid(if (on) cBlue else cOff, 12)
        val knob = View(this)
        val kg = GradientDrawable()
        kg.shape = GradientDrawable.OVAL
        kg.setColor(Color.WHITE)
        knob.background = kg
        val k = FrameLayout.LayoutParams(dp(18), dp(18))
        k.gravity = Gravity.CENTER_VERTICAL or (if (on) Gravity.RIGHT else Gravity.LEFT)
        k.setMargins(dp(3), 0, dp(3), 0)
        f.addView(knob, k)
        return f
    }

    private fun header(title: String, icon: String, iconColor: Int, onBack: (() -> Unit)?): View {
        val row = hrow()
        row.layoutDirection = View.LAYOUT_DIRECTION_LTR
        val left: View = if (onBack != null) iconBtn("‹") { onBack() } else View(this)
        row.addView(left, LinearLayout.LayoutParams(dp(34), dp(34)))
        val mid = hrow()
        mid.layoutDirection = View.LAYOUT_DIRECTION_RTL
        mid.gravity = Gravity.CENTER
        mid.addView(label(title, 17f, Color.WHITE, true))
        if (icon.isNotEmpty()) {
            val ic = label(icon, 20f, iconColor, true)
            ic.setPadding(0, 0, dp(8), 0)
            mid.addView(ic)
        }
        row.addView(mid, llp(0, WRAP, 1f))
        row.addView(iconBtn("✕") { closePanel() }, LinearLayout.LayoutParams(dp(34), dp(34)))
        return row
    }

    // ------------------------------------------------------------ windows
    private fun newLp(w: Int, h: Int): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.LEFT
        return lp
    }

    private fun clampTo(lp: WindowManager.LayoutParams) {
        lp.x = lp.x.coerceIn(0, maxOf(0, sw() - lp.width))
        lp.y = lp.y.coerceIn(0, maxOf(0, sh() - lp.height))
    }

    private fun crownBg(): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(0xF20E1322.toInt())
        g.setStroke(dp(2), cBorder)
        return g
    }

    // ------------------------------------------------------------ bubble
    private fun showBubble() {
        if (bubble != null) return
        val size = dp(52)
        val tv = TextView(this)
        tv.text = "👑"
        tv.textSize = 22f
        tv.gravity = Gravity.CENTER
        tv.background = crownBg()
        tv.elevation = dp(6).toFloat()
        val lp = newLp(size, size)
        lp.x = prefs.getInt("bx", sw() - size)
        lp.y = prefs.getInt("by", sh() / 3)
        clampTo(lp)
        tv.setOnTouchListener(BubbleTouch())
        wm.addView(tv, lp)
        bubble = tv
        bubbleLp = lp
    }

    private inner class BubbleTouch : View.OnTouchListener {
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        private var moved = false
        private val slop = ViewConfiguration.get(this@FloatService).scaledTouchSlop

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            val lp = bubbleLp ?: return false
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = lp.x; startY = lp.y
                    moved = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && (Math.abs(dx) > slop || Math.abs(dy) > slop)) moved = true
                    if (moved) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        clampTo(lp)
                        wm.updateViewLayout(v, lp)
                        if (panel != null) placePanel()
                    }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        // dock to the nearest side edge
                        lp.x = if (lp.x + lp.width / 2 < sw() / 2) 0 else sw() - lp.width
                        wm.updateViewLayout(v, lp)
                        prefs.edit().putInt("bx", lp.x).putInt("by", lp.y).apply()
                        if (panel != null) placePanel()
                    } else {
                        buzz(v)
                        if (panel == null) openPanel() else closePanel()
                    }
                    return true
                }
            }
            return false
        }
    }

    // ------------------------------------------------------------ panel
    private fun openPanel() {
        if (panel != null || mode != Mode.NORMAL) return
        val root = FrameLayout(this)
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.background = solid(cPanel, 20, dp(2), cBorder)
        root.setPadding(dp(12), dp(8), dp(12), dp(10))
        root.elevation = dp(8).toFloat()
        val bw = bubbleLp?.width ?: dp(52)
        val w = minOf(dp(300), sw() - bw - dp(12))
        val lp = newLp(w, WindowManager.LayoutParams.WRAP_CONTENT)
        panel = root
        panelLp = lp
        showMain()
        wm.addView(root, lp)
    }

    private fun closePanel() {
        panel?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        panel = null
        panelLp = null
    }

    private fun setPage(v: View) {
        val root = panel ?: return
        root.removeAllViews()
        root.addView(v)
        placePanel()
    }

    private fun placePanel() {
        val root = panel ?: return
        val lp = panelLp ?: return
        val b = bubbleLp ?: return
        root.measure(
            View.MeasureSpec.makeMeasureSpec(lp.width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(sh() - dp(16), View.MeasureSpec.AT_MOST)
        )
        val h = root.measuredHeight
        val bubbleOnRight = b.x + b.width / 2 >= sw() / 2
        var x = if (bubbleOnRight) b.x - lp.width - dp(6) else b.x + b.width + dp(6)
        x = x.coerceIn(dp(4), maxOf(dp(4), sw() - lp.width - dp(4)))
        var y = b.y + b.height / 2 - h / 2
        y = y.coerceIn(dp(8), maxOf(dp(8), sh() - h - dp(8)))
        lp.x = x
        lp.y = y
        if (root.isAttachedToWindow) {
            try { wm.updateViewLayout(root, lp) } catch (e: Exception) { }
        }
    }

    private fun replace() {
        panel?.post { placePanel() }
    }

    // ------------------------------------------------------------ MAIN page
    private fun flip(key: String) {
        val now = !prefs.getBoolean(key, false)
        val ed = prefs.edit().putBoolean(key, now)
        // turning on a writing mode also turns the master switch on
        if (now && (key == "w_sep" || key == "w_dot" || key == "w_rev")) ed.putBoolean("w_on", true)
        ed.apply()
        showMain()
    }

    private fun mainRow(
        icon: String, iconColor: Int, name: String, trailing: View,
        onLong: (() -> Unit)? = null, click: () -> Unit
    ): View {
        val r = hrow()
        r.setPadding(dp(12), 0, dp(12), 0)
        r.background = rowBg()
        val ic = label(icon, 18f, iconColor, true)
        ic.gravity = Gravity.CENTER
        r.addView(ic, LinearLayout.LayoutParams(dp(32), WRAP))
        val tx = label(name, 14f, Color.WHITE, false)
        val tlp = llp(0, WRAP, 1f)
        tlp.setMargins(dp(8), 0, dp(8), 0)
        r.addView(tx, tlp)
        if (trailing is FrameLayout) r.addView(trailing, LinearLayout.LayoutParams(dp(44), dp(24)))
        else r.addView(trailing)
        r.setOnClickListener { buzz(it); click() }
        if (onLong != null) r.setOnLongClickListener { buzz(it); onLong(); true }
        return r
    }

    private fun chevron(): View = label("‹", 22f, cMuted, false)

    private fun showMain() {
        val col = vcol()

        // drag-handle look + header
        val handle = View(this)
        handle.background = solid(0x55FFFFFF, 3)
        col.addView(handle, LinearLayout.LayoutParams(dp(34), dp(4)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(4)
        })

        val head = hrow()
        head.layoutDirection = View.LAYOUT_DIRECTION_LTR
        val logo = label("👑", 20f, cBlue, false)
        head.addView(logo)
        val name = label("NDR TOOLS", 17f, cBlue, true)
        name.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
        name.setPadding(dp(8), 0, 0, 0)
        head.addView(name, llp(0, WRAP, 1f))
        head.addView(iconBtn("✕") { closePanel() }, LinearLayout.LayoutParams(dp(34), dp(34)))
        col.addView(head, llp(MATCH, WRAP))
        col.addView(divider())

        fun on(k: String) = prefs.getBoolean(k, false)

        val rows = vcol()
        fun add(v: View) = rows.addView(v, llp(MATCH, dp(44), 0f, 2))

        add(mainRow("⌨", cBlue, "الكتابة", toggleView(on("w_on"))) { flip("w_on") })
        add(mainRow("Aᵇ", cBlue, "فكك", toggleView(on("w_sep")),
            { closePanel(); transform(true, false, false) }) { flip("w_sep") })
        add(mainRow("•••", cBlue, "نقط", toggleView(on("w_dot")),
            { closePanel(); transform(false, true, false) }) { flip("w_dot") })
        add(mainRow("⇄", cBlue, "عكس", toggleView(on("w_rev")),
            { closePanel(); transform(false, false, true) }) { flip("w_rev") })
        add(mainRow("🇩🇿", cBlue, "ولايات", chevron()) { showWilayas() })
        add(mainRow("♂", cBlue, "ولد", chevron()) { showCats() })
        add(mainRow("⚡", cBlue, "تكبيس", chevron()) { showClick() })
        add(mainRow("🔊", cBlue, "قارئ الإيموجي", toggleView(on("emoji_read"))) { flip("emoji_read") })
        add(mainRow("🏆", cBlue, "رقم الكأس", chevron()) { showValue("val_cup", "رقم الكأس", "🏆") })
        add(mainRow("#", cBlue, "الروم ID", chevron()) { showValue("val_room", "الروم ID", "#") })

        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(rows)
        val full = 10 * (dp(44) + dp(4)) + dp(4)
        val maxH = sh() - dp(190)
        col.addView(sv, LinearLayout.LayoutParams(MATCH, minOf(full, maxH)))

        col.addView(divider())
        val foot = hrow()
        foot.layoutDirection = View.LAYOUT_DIRECTION_LTR
        val gear = label("⚙  الإعدادات", 12f, cText, false)
        gear.setOnClickListener { buzz(it); openSettings() }
        gear.setPadding(0, dp(4), dp(12), dp(4))
        foot.addView(gear, llp(0, WRAP, 1f))
        foot.addView(label("v1.0", 12f, cMuted, false))
        col.addView(foot, llp(MATCH, WRAP))

        setPage(col)
    }

    private fun openSettings() {
        closePanel()
        val i = Intent(this, SettingsActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    // ------------------------------------------------------------ boy / girl / animal ...
    private fun showCats() {
        val col = vcol()
        col.addView(header("ولد", "♂", cBlue) { showMain() })
        col.addView(divider())
        val sub = label("اختر الأنواع التي تريدها", 13f, cText, false)
        sub.gravity = Gravity.CENTER
        col.addView(sub, llp(MATCH, WRAP, 0f, 2))

        val cards = LinkedHashMap<String, Pair<LinearLayout, TextView>>()
        fun paint() {
            for ((k, v) in cards) {
                val on = k in selectedCats
                v.first.background = if (on) solid(cRowOn, 12, dp(1), cBlue) else rowBg()
                v.second.text = if (on) "✓" else ""
                v.second.background = if (on) solid(cBlue, 5) else solid(0x00000000, 5, dp(1), cMuted)
            }
        }

        val grid = vcol()
        grid.layoutDirection = View.LAYOUT_DIRECTION_LTR
        var rowL: LinearLayout? = null
        for ((i, m) in catMeta.withIndex()) {
            if (i % 2 == 0) {
                rowL = hrow()
                grid.addView(rowL, llp(MATCH, WRAP))
            }
            val c = hrow()
            c.setPadding(dp(10), 0, dp(10), 0)
            val ic = label(m.third, 18f, if (m.first == "girl") cViolet else cBlue, true)
            ic.gravity = Gravity.CENTER
            c.addView(ic, LinearLayout.LayoutParams(dp(28), WRAP))
            val tx = label(m.second, 14f, Color.WHITE, false)
            tx.gravity = Gravity.CENTER
            c.addView(tx, llp(0, WRAP, 1f))
            val box = label("", 13f, Color.WHITE, true)
            box.gravity = Gravity.CENTER
            c.addView(box, LinearLayout.LayoutParams(dp(20), dp(20)))
            cards[m.first] = Pair(c, box)
            c.setOnClickListener {
                buzz(it)
                if (m.first in selectedCats) selectedCats.remove(m.first) else selectedCats.add(m.first)
                paint()
            }
            rowL?.addView(c, llp(0, dp(46), 1f, 3))
        }
        if (catMeta.size % 2 == 1) {
            rowL?.addView(View(this), llp(0, dp(46), 1f, 3))
        }
        col.addView(grid)
        paint()
        col.addView(divider())

        val btns = hrow()
        btns.layoutDirection = View.LAYOUT_DIRECTION_LTR
        btns.addView(outlineBtn("تحديد الكل  ✓", cText) {
            selectedCats.clear(); selectedCats.addAll(catMeta.map { it.first }); paint()
        }, llp(0, dp(40), 1f, 3))
        btns.addView(outlineBtn("مسح  🗑", cText) { selectedCats.clear(); paint() }, llp(0, dp(40), 1f, 3))
        col.addView(btns)
        col.addView(primaryBtn("تأكيد  ✓") {
            if (selectedCats.isEmpty()) toast("اختر قسماً واحداً على الأقل") else showLetters()
        }, llp(MATCH, dp(46), 0f, 3))
        setPage(col)
    }

    private fun letterGrid(onLetter: (Char) -> Unit): View {
        val box = vcol()
        val letters = GameData.letters
        var i = 0
        while (i < letters.length) {
            val row = hrow()
            for (j in 0 until 7) {
                if (i + j >= letters.length) break
                val ch = letters[i + j]
                val b = label(ch.toString(), 18f, Color.WHITE, true)
                b.gravity = Gravity.CENTER
                b.background = rowBg()
                b.setOnClickListener { buzz(it); onLetter(ch) }
                row.addView(b, llp(0, dp(42), 1f, 2))
            }
            box.addView(row, llp(MATCH, WRAP))
            i += 7
        }
        return box
    }

    private fun showLetters() {
        val col = vcol()
        col.addView(header("اختر الحرف", "", cBlue) { showCats() })
        col.addView(divider())
        val names = catMeta.filter { it.first in selectedCats }.joinToString("، ") { it.second }
        val sub = label(names, 12f, cMuted, false)
        sub.gravity = Gravity.CENTER
        col.addView(sub, llp(MATCH, WRAP, 0f, 2))
        val msg = label("اضغط حرفاً ليُدرج في خانة الكتابة", 12f, cBlue, false)
        msg.gravity = Gravity.CENTER
        msg.setPadding(dp(4), dp(8), dp(4), dp(2))
        col.addView(letterGrid { sendLetter(it, msg) })
        col.addView(msg, llp(MATCH, WRAP))
        setPage(col)
    }

    private fun sendLetter(ch: Char, msg: TextView) {
        val letter = GameData.normalize(ch)
        val words = ArrayList<String>()
        val shown = ArrayList<String>()
        for (m in catMeta) {
            if (m.first !in selectedCats) continue
            val w = GameData.catData[m.first]?.get(letter) ?: continue
            words.add(w)
            shown.add(m.second + ": " + w)
        }
        if (words.isEmpty()) {
            msg.text = "😅 لا توجد كلمة بحرف «$ch» في الأقسام المختارة"
        } else if (insertText(words.joinToString("، ") + " ")) {
            msg.text = "✅ " + shown.joinToString("  |  ")
        }
        replace()
    }

    private fun showWilayas() {
        val col = vcol()
        col.addView(header("ولايات", "🇩🇿", cBlue) { showMain() })
        col.addView(divider())
        val sub = label("اختر الحرف لإدراج ولاية جزائرية", 13f, cText, false)
        sub.gravity = Gravity.CENTER
        col.addView(sub, llp(MATCH, WRAP, 0f, 2))
        val msg = label("اضغط الحرف نفسه مرة أخرى لولاية أخرى بنفس الحرف", 12f, cBlue, false)
        msg.gravity = Gravity.CENTER
        msg.setPadding(dp(4), dp(8), dp(4), dp(2))
        col.addView(letterGrid { ch ->
            val letter = GameData.normalize(ch)
            val list = Wilayas.byLetter(letter)
            if (list.isEmpty()) {
                msg.text = "😅 لا توجد ولاية بحرف «$ch»"
            } else {
                val i = (wilayaIdx[letter] ?: 0) % list.size
                wilayaIdx[letter] = i + 1
                val w = list[i]
                if (insertText("$w ")) msg.text = "✅ $w (" + Wilayas.number(w) + ")"
            }
            replace()
        })
        col.addView(msg, llp(MATCH, WRAP))
        setPage(col)
    }

    // ------------------------------------------------------------ saved values
    private fun showValue(key: String, title: String, icon: String) {
        val col = vcol()
        col.addView(header(title, icon, cBlue) { showMain() })
        col.addView(divider())
        val cur = prefs.getString(key, "") ?: ""
        val empty = cur.isEmpty()
        val box = label(if (empty) "لا توجد قيمة محفوظة" else cur, if (empty) 13f else 22f,
            if (empty) cMuted else Color.WHITE, true)
        box.gravity = Gravity.CENTER
        box.setPadding(dp(10), dp(18), dp(10), dp(18))
        box.background = rowBg()
        col.addView(box, llp(MATCH, WRAP, 0f, 3))
        col.addView(primaryBtn("إدراج  ✓") {
            if (empty) toast("احفظ قيمة أولاً") else if (insertText(cur)) closePanel()
        }, llp(MATCH, dp(46), 0f, 3))
        val r = hrow()
        r.layoutDirection = View.LAYOUT_DIRECTION_LTR
        r.addView(outlineBtn("📥 حفظ من الحقل", cText) {
            val t = selectedOrAllText()
            if (t.isNullOrBlank()) toast("اكتب القيمة في خانة الكتابة أولاً")
            else { prefs.edit().putString(key, t.trim()).apply(); showValue(key, title, icon) }
        }, llp(0, dp(40), 1f, 3))
        r.addView(outlineBtn("🗑 مسح", cText) {
            prefs.edit().remove(key).apply(); showValue(key, title, icon)
        }, llp(0, dp(40), 1f, 3))
        col.addView(r)
        setPage(col)
    }

    // ------------------------------------------------------------ auto click page
    private fun showClick() {
        val col = vcol()
        col.addView(header("التكبيس", "⚡", cBlue) { showMain() })
        col.addView(divider())
        col.addView(label("عدد التكبيسات", 14f, Color.WHITE, true), llp(MATCH, WRAP, 0f, 3))

        val counts = listOf(50, 100, 300, 1000)
        val box = vcol()
        box.layoutDirection = View.LAYOUT_DIRECTION_LTR
        box.background = rowBg()
        val radios = ArrayList<TextView>()
        var sel = prefs.getInt("click_count", 300)
        fun paintR() {
            for (i in counts.indices) {
                val on = counts[i] == sel
                radios[i].text = if (on) "◉" else "○"
                radios[i].setTextColor(if (on) cBlue else cMuted)
            }
        }
        for (c in counts) {
            val r = hrow()
            r.setPadding(dp(12), dp(7), dp(12), dp(7))
            val rd = label("○", 20f, cMuted, false)
            radios.add(rd)
            r.addView(rd)
            val tx = label("$c تكبيسة", 15f, Color.WHITE, false)
            val tlp = llp(0, WRAP, 1f)
            tlp.setMargins(dp(12), 0, 0, 0)
            r.addView(tx, tlp)
            r.setOnClickListener {
                buzz(it)
                sel = c
                prefs.edit().putInt("click_count", c).apply()
                paintR()
            }
            box.addView(r)
        }
        paintR()
        col.addView(box, llp(MATCH, WRAP, 0f, 2))

        col.addView(label("سرعة التكبيس", 14f, Color.WHITE, true), llp(MATCH, WRAP, 0f, 3))
        var speed = prefs.getInt("click_speed", 75)
        val speedTv = label("السرعة: $speed%", 12f, cMuted, false)
        speedTv.gravity = Gravity.CENTER
        fun applySpeed(v: Int) {
            speed = v
            prefs.edit().putInt("click_speed", v).apply()
            speedTv.text = "السرعة: $v%"
        }
        val slider = SliderView(this, speed) { v -> applySpeed(v) }
        val sr = hrow()
        sr.layoutDirection = View.LAYOUT_DIRECTION_LTR
        val minus = iconBtn("−") { val v = (speed - 5).coerceAtLeast(0); slider.set(v); applySpeed(v) }
        val plus = iconBtn("+") { val v = (speed + 5).coerceAtMost(100); slider.set(v); applySpeed(v) }
        sr.addView(minus, LinearLayout.LayoutParams(dp(30), dp(34)))
        sr.addView(slider, llp(0, dp(34), 1f))
        sr.addView(plus, LinearLayout.LayoutParams(dp(30), dp(34)))
        col.addView(sr, llp(MATCH, WRAP))
        col.addView(speedTv, llp(MATCH, WRAP, 0f, 2))

        col.addView(primaryBtn("▶   بدء التكبيس") { beginSetup() }, llp(MATCH, dp(46), 0f, 3))
        setPage(col)
    }

    // ------------------------------------------------------------ focused field helpers
    private fun focusedField(): AccessibilityNodeInfo? {
        var f: AccessibilityNodeInfo? = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (f == null) {
            for (w in windows) {
                if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
                val r = w.root ?: continue
                f = r.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                if (f != null) break
            }
        }
        if (f != null && f.isEditable) {
            lastEditable = f
            return f
        }
        val last = lastEditable
        if (last != null && last.refresh() && last.isEditable && last.isFocused) return last
        return null
    }

    private fun fieldText(n: AccessibilityNodeInfo): String {
        if (Build.VERSION.SDK_INT >= 26 && n.isShowingHintText) return ""
        return n.text?.toString() ?: ""
    }

    private fun setFieldText(n: AccessibilityNodeInfo, text: String, cursor: Int): Boolean {
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        lastSet = text
        val ok = n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (ok) {
            val sel = Bundle()
            sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, cursor)
            sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, cursor)
            n.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel)
        }
        return ok
    }

    private fun pasteInstead(n: AccessibilityNodeInfo, s: String): Boolean {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("ndr", s))
        val ok = n.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        if (!ok) toast("هذه الخانة لا تقبل الإدراج التلقائي")
        return ok
    }

    private fun noField() = toast("اضغط داخل خانة الكتابة أولاً")

    /** Selected text if any, otherwise the whole text of the focused field. */
    private fun selectedOrAllText(): String? {
        val n = focusedField() ?: return null
        val cur = fieldText(n)
        val a = n.textSelectionStart
        val b = n.textSelectionEnd
        return if (a >= 0 && b > a && b <= cur.length) cur.substring(a, b) else cur
    }

    private fun insertText(s: String): Boolean {
        val n = focusedField()
        if (n == null) { noField(); return false }
        val cur = fieldText(n)
        var a = n.textSelectionStart
        var b = n.textSelectionEnd
        if (a < 0 || b < 0 || a > cur.length || b > cur.length) { a = cur.length; b = cur.length }
        if (a > b) { val t = a; a = b; b = t }
        val out = cur.substring(0, a) + s + cur.substring(b)
        undoText = cur
        if (!setFieldText(n, out, a + s.length)) return pasteInstead(n, s)
        return true
    }

    private fun transform(sep: Boolean, dot: Boolean, rev: Boolean) {
        val n = focusedField()
        if (n == null) { noField(); return }
        val cur = fieldText(n)
        val a = n.textSelectionStart
        val b = n.textSelectionEnd
        val hasSel = a >= 0 && b > a && b <= cur.length
        val src = if (hasSel) cur.substring(a, b) else cur
        if (src.isEmpty()) { toast("اكتب نصاً أولاً"); return }
        val res = TextTools.style(src, sep, dot, rev)
        val out = if (hasSel) cur.substring(0, a) + res + cur.substring(b) else res
        undoText = cur
        if (!setFieldText(n, out, if (hasSel) a + res.length else res.length)) {
            toast("هذه الخانة لا تسمح بتعديل النص تلقائياً")
        }
    }

    // ------------------------------------------------------------ events
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !::prefs.isInitialized) return
        when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_FOCUSED -> {
                val s = event.source
                if (s != null && s.isEditable) lastEditable = s
            }
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> {
                if (event.packageName?.toString() == packageName) return
                if (prefs.getBoolean("emoji_read", false)) readTypedEmojis(event)
                handleLive(event)
            }
            AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED -> {
                if (prefs.getBoolean("emoji_read", false)) {
                    val t = event.text.joinToString(" ") { it.toString() }
                    speakEmojis(t)
                }
            }
        }
    }

    /** Writing modes applied while typing (works with any keyboard). */
    private fun handleLive(e: AccessibilityEvent) {
        if (!prefs.getBoolean("w_on", false)) return
        val sep = prefs.getBoolean("w_sep", false)
        val dot = prefs.getBoolean("w_dot", false)
        val rev = prefs.getBoolean("w_rev", false)
        if (!sep && !dot && !rev) return
        if (e.addedCount != 1 || e.removedCount != 0) return
        if (e.isPassword) return
        val src = e.source ?: return
        if (!src.isEditable || src.isPassword) return
        val full = src.text?.toString() ?: return
        if (full == lastSet) return
        val before = e.beforeText
        if (before != null && full.length != before.length + 1) return
        val idx = e.fromIndex
        if (idx < 0 || idx >= full.length) return
        val ch = full[idx]
        val s = TextTools.sepOf(sep, dot)
        var out: String
        var cursor: Int
        if (rev) {
            if (idx != full.length - 1) return
            val rest = full.substring(0, idx)
            val head = rest.firstOrNull()
            val glue = when {
                ch.isLetterOrDigit() && head != null && head.isLetterOrDigit() -> s
                sep && ch == ' ' && head != null && head.isLetterOrDigit() -> " "
                else -> ""
            }
            out = ch.toString() + glue + rest
            cursor = out.length
        } else {
            val prev = if (idx > 0) full[idx - 1] else ' '
            if (ch.isLetterOrDigit() && prev.isLetterOrDigit() && s.isNotEmpty()) {
                out = full.substring(0, idx) + s + full.substring(idx)
                cursor = idx + s.length + 1
            } else if (sep && ch == ' ' && prev.isLetterOrDigit()) {
                out = full.substring(0, idx) + " " + full.substring(idx)
                cursor = idx + 2
            } else {
                return
            }
        }
        setFieldText(src, out, cursor)
    }

    // ------------------------------------------------------------ emoji reader
    private fun readTypedEmojis(e: AccessibilityEvent) {
        if (e.isPassword || e.addedCount <= 0) return
        val full = e.text?.firstOrNull()?.toString() ?: return
        val idx = e.fromIndex
        if (idx < 0 || idx + e.addedCount > full.length) return
        speakEmojis(full.substring(idx, idx + e.addedCount))
    }

    private fun speakEmojis(text: String) {
        val found = TextTools.extractEmojis(text)
        if (found.isEmpty()) return
        speak(found.take(8).joinToString("، ") { TextTools.emojiName(it.first) })
    }

    private fun speak(s: String) {
        val t = tts
        if (t == null) {
            ttsPending = s
            tts = TextToSpeech(this) { st ->
                if (st == TextToSpeech.SUCCESS) {
                    val r = tts?.setLanguage(Locale("ar"))
                    ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                    if (ttsReady) {
                        ttsPending?.let { tts?.speak(it, TextToSpeech.QUEUE_ADD, null, "ndr") }
                    } else {
                        toast("صوت اللغة العربية غير مثبّت في محرك النطق")
                    }
                } else {
                    toast("تعذّر تشغيل محرك النطق")
                }
                ttsPending = null
            }
            return
        }
        if (ttsReady) t.speak(s, TextToSpeech.QUEUE_ADD, null, "ndr")
    }

    // ------------------------------------------------------------ auto clicker
    private fun beginSetup() {
        closePanel()
        bubble?.visibility = View.INVISIBLE
        showTarget()
        mode = Mode.SETUP
        showCard(false)
    }

    private fun showTarget() {
        if (target != null) return
        val size = dp(54)
        val tv = TextView(this)
        tv.text = "🎯"
        tv.textSize = 22f
        tv.gravity = Gravity.CENTER
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(0x44FF5C6C)
        g.setStroke(dp(2), cRed)
        tv.background = g
        val lp = newLp(size, size)
        lp.x = (sw() - size) / 2
        lp.y = (sh() - size) / 2
        tv.setOnTouchListener(DragTouch(lp))
        wm.addView(tv, lp)
        target = tv
        targetLp = lp
    }

    private inner class DragTouch(val lp: WindowManager.LayoutParams) : View.OnTouchListener {
        private var dx = 0f
        private var dy = 0f
        private var sx = 0
        private var sy = 0
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = (sx + (e.rawX - dx)).toInt()
                    lp.y = (sy + (e.rawY - dy)).toInt()
                    clampTo(lp)
                    wm.updateViewLayout(v, lp)
                }
            }
            return true
        }
    }

    /** Setup card (choose the spot) or running card (progress), styled like the mock-up. */
    private fun showCard(running: Boolean) {
        removeCard()
        val root = FrameLayout(this)
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.background = solid(cPanel, 18, dp(2), if (running) cGreen else cBorder)
        root.setPadding(dp(14), dp(10), dp(14), dp(12))
        root.elevation = dp(8).toFloat()
        val col = vcol()

        if (!running) {
            val h = hrow()
            h.layoutDirection = View.LAYOUT_DIRECTION_LTR
            h.addView(label("🎯  حدّد مكان التكبيس", 15f, Color.WHITE, true), llp(0, WRAP, 1f))
            col.addView(h, llp(MATCH, WRAP))
            col.addView(divider())
            val t = label("اسحب الدائرة 🎯 إلى المكان المطلوب ثم اضغط ابدأ", 13f, cText, false)
            t.gravity = Gravity.CENTER
            col.addView(t, llp(MATCH, WRAP, 0f, 2))
            val r = hrow()
            r.layoutDirection = View.LAYOUT_DIRECTION_LTR
            r.addView(outlineBtn("إلغاء", cRed) { stopClicking(false) }, llp(0, dp(42), 1f, 3))
            r.addView(primaryBtn("▶  ابدأ") { startClicking() }, llp(0, dp(42), 1f, 3))
            col.addView(r)
        } else {
            val h = hrow()
            h.layoutDirection = View.LAYOUT_DIRECTION_LTR
            h.addView(label("⚡", 18f, cGreen, true))
            val tt = label("التكبيس قيد التشغيل", 14f, cGreen, true)
            tt.setPadding(dp(8), 0, 0, 0)
            h.addView(tt, llp(0, WRAP, 1f))
            val stop = label("■", 14f, Color.WHITE, true)
            stop.gravity = Gravity.CENTER
            val sg = GradientDrawable()
            sg.shape = GradientDrawable.OVAL
            sg.setColor(0xFF1B2236.toInt())
            sg.setStroke(dp(1), cBorderSoft)
            stop.background = sg
            stop.setOnClickListener { buzz(it); stopClicking(true) }
            h.addView(stop, LinearLayout.LayoutParams(dp(32), dp(32)))
            col.addView(h, llp(MATCH, WRAP))
            col.addView(divider())

            val cnt = label("$clicksDone / $clicksTotal", 20f, Color.WHITE, true)
            cnt.layoutDirection = View.LAYOUT_DIRECTION_LTR
            col.addView(cnt, llp(MATCH, WRAP, 0f, 1))
            runCountTv = cnt

            val track = LinearLayout(this)
            track.layoutDirection = View.LAYOUT_DIRECTION_LTR
            track.weightSum = 1f
            track.background = solid(0xFF2A3145.toInt(), 5)
            val bar = View(this)
            bar.background = solid(cGreen, 5)
            track.addView(bar, LinearLayout.LayoutParams(0, MATCH, 0f))
            runBar = bar
            col.addView(track, llp(MATCH, dp(10), 0f, 3))

            val sp = label("⇄  السرعة: " + prefs.getInt("click_speed", 75) + "%", 13f, cText, false)
            col.addView(sp, llp(MATCH, WRAP, 0f, 3))

            val st = label("⏸   إيقاف", 15f, cRed, true)
            st.gravity = Gravity.CENTER
            st.background = solid(0x22FF5C6C, 14, dp(1), cRed)
            st.setOnClickListener { buzz(it); stopClicking(true) }
            col.addView(st, llp(MATCH, dp(44), 0f, 3))
        }

        root.addView(col)
        val lp = newLp(minOf(dp(290), sw() - dp(24)), WindowManager.LayoutParams.WRAP_CONTENT)
        card = root
        cardLp = lp
        placeCard(running)
        wm.addView(root, lp)
    }

    private fun placeCard(running: Boolean) {
        val root = card ?: return
        val lp = cardLp ?: return
        root.measure(
            View.MeasureSpec.makeMeasureSpec(lp.width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(sh(), View.MeasureSpec.AT_MOST)
        )
        lp.x = (sw() - lp.width) / 2
        // keep the card away from the spot being clicked
        val targetCenterY = if (running) clickY else sh() / 2f
        lp.y = if (targetCenterY > sh() / 2f) dp(48) else sh() - root.measuredHeight - dp(48)
    }

    private fun removeCard() {
        card?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        card = null
        cardLp = null
        runCountTv = null
        runBar = null
    }

    private fun startClicking() {
        val t = target ?: return
        val lp = targetLp ?: return
        val loc = IntArray(2)
        t.getLocationOnScreen(loc)
        clickX = loc[0] + t.width / 2f
        clickY = loc[1] + t.height / 2f
        // the marker must let the taps through
        lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        t.alpha = 0.6f
        try { wm.updateViewLayout(t, lp) } catch (e: Exception) { }
        clicksTotal = prefs.getInt("click_count", 300)
        clicksDone = 0
        mode = Mode.RUNNING
        showCard(true)
        handler.postDelayed(clickRunnable, 600)
    }

    private val clickRunnable = object : Runnable {
        override fun run() {
            if (mode != Mode.RUNNING) return
            tapAt(clickX, clickY)
            clicksDone++
            updateRun()
            if (clicksDone >= clicksTotal) {
                stopClicking(true)
                return
            }
            val speed = prefs.getInt("click_speed", 75)
            val ms = (1000 - speed * 9).coerceAtLeast(100)
            handler.postDelayed(this, ms.toLong())
        }
    }

    private fun updateRun() {
        runCountTv?.text = "$clicksDone / $clicksTotal"
        val bar = runBar ?: return
        val lp = bar.layoutParams as LinearLayout.LayoutParams
        lp.weight = if (clicksTotal > 0) (clicksDone.toFloat() / clicksTotal).coerceIn(0f, 1f) else 0f
        bar.layoutParams = lp
    }

    private fun tapAt(x: Float, y: Float) {
        val p = Path()
        p.moveTo(x, y)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 30))
            .build()
        dispatchGesture(g, null, null)
    }

    private fun stopClicking(announce: Boolean) {
        handler.removeCallbacks(clickRunnable)
        val done = clicksDone
        target?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        target = null
        targetLp = null
        removeCard()
        val wasActive = mode != Mode.NORMAL
        mode = Mode.NORMAL
        bubble?.visibility = View.VISIBLE
        if (announce && wasActive && done > 0) toast("تم: $done تكبيسة")
        clicksDone = 0
    }
}
