package com.ndr.tools

import android.content.Context
import android.content.SharedPreferences
import java.text.BreakIterator
import java.util.Locale

object Prefs {
    fun get(c: Context): SharedPreferences =
        c.getSharedPreferences("ndr_prefs", Context.MODE_PRIVATE)
}

object TextTools {

    /** Split into user-visible characters (keeps emoji sequences and Arabic marks together). */
    fun graphemes(s: String): List<String> {
        val out = ArrayList<String>()
        if (s.isEmpty()) return out
        val bi = BreakIterator.getCharacterInstance()
        bi.setText(s)
        var start = bi.first()
        var end = bi.next()
        while (end != BreakIterator.DONE) {
            out.add(s.substring(start, end))
            start = end
            end = bi.next()
        }
        return out
    }

    /** The separator placed between two characters for the chosen modes. */
    fun sepOf(sep: Boolean, dot: Boolean): String = when {
        sep && dot -> " . "
        sep -> " "
        dot -> "."
        else -> ""
    }

    /**
     * Whole-text conversion.
     * sep: "ا ح م د"   dot: "ا.ح.م.د"   rev: reversed order ("كاس" -> "ساك").
     * Between two words: a double gap in separated mode, a single space otherwise.
     */
    fun style(s: String, sep: Boolean, dot: Boolean, rev: Boolean): String {
        val sp = sepOf(sep, dot)
        val gap = if (sep) "  " else " "
        val sb = StringBuilder()
        var pending = false
        for (g in graphemes(s)) {
            if (g == "\n" || g == "\r\n" || g == "\r") {
                sb.append(g); pending = false
            } else if (g.isBlank()) {
                if (sp.isNotEmpty()) sb.append(gap) else sb.append(g)
                pending = false
            } else {
                if (pending && sp.isNotEmpty()) sb.append(sp)
                sb.append(g)
                pending = true
            }
        }
        val spaced = sb.toString()
        return if (rev) reverse(spaced) else spaced
    }

    fun reverse(s: String): String =
        s.split("\n").joinToString("\n") { line -> graphemes(line).reversed().joinToString("") }

    // ------------------------------------------------------------------ emoji

    fun isEmoji(g: String): Boolean {
        if (g.isEmpty()) return false
        if (g.contains('\u20E3')) return true
        val cp = g.codePointAt(0)
        return cp in 0x1F000..0x1FAFF || cp in 0x2600..0x27BF || cp in 0x2300..0x23FF ||
            cp in 0x2B00..0x2BFF || cp == 0x203C || cp == 0x2049 || cp == 0x2122
    }

    private fun norm(g: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < g.length) {
            val cp = g.codePointAt(i)
            i += Character.charCount(cp)
            if (cp == 0xFE0F || cp == 0xFE0E) continue
            if (cp in 0x1F3FB..0x1F3FF) continue
            sb.appendCodePoint(cp)
        }
        return sb.toString()
    }

    /** Distinct emojis in order of appearance with their counts. */
    fun extractEmojis(s: String): List<Pair<String, Int>> {
        val m = LinkedHashMap<String, Int>()
        for (g in graphemes(s)) {
            if (!isEmoji(g)) continue
            m[g] = (m[g] ?: 0) + 1
        }
        return m.entries.map { Pair(it.key, it.value) }
    }

    fun emojiName(g: String): String {
        val n = norm(g)
        NAMES[n]?.let { return it }
        val first = n.split('\u200D').firstOrNull()
        if (first != null) NAMES[first]?.let { return it }
        flagName(n)?.let { return it }
        if (n.endsWith("\u20E3")) return "مفتاح " + n.dropLast(1)
        return "إيموجي"
    }

    private fun flagName(n: String): String? {
        if (n.codePointCount(0, n.length) != 2) return null
        val a = n.codePointAt(0)
        val b = n.codePointAt(n.offsetByCodePoints(0, 1))
        if (a !in 0x1F1E6..0x1F1FF || b !in 0x1F1E6..0x1F1FF) return null
        val code = "" + (a - 0x1F1E6 + 'A'.code).toChar() + (b - 0x1F1E6 + 'A'.code).toChar()
        val name = Locale("", code).getDisplayCountry(Locale("ar"))
        return if (name.isNullOrEmpty() || name == code) "علم $code" else "علم $name"
    }

    private val NAMES: Map<String, String> by lazy {
        val m = HashMap<String, String>()
        for (line in RAW.split('\n')) {
            val i = line.indexOf('=')
            if (i <= 0) continue
            m[norm(line.substring(0, i).trim())] = line.substring(i + 1).trim()
        }
        m
    }

    private const val RAW = """
😀=وجه مبتسم
😃=وجه مبتسم بعينين كبيرتين
😄=وجه ضاحك
😁=وجه مبتهج
😆=ضحك بعينين مغمضتين
😅=ضحك مع عرق
🤣=يتمرغ من الضحك
😂=دموع الفرح
🙂=ابتسامة خفيفة
🙃=وجه مقلوب
😉=غمزة
😊=وجه مبتسم خجول
😇=وجه بهالة ملاك
🥰=وجه محب بقلوب
😍=عيون قلوب
🤩=عيون نجوم
😘=قبلة
😗=وجه يقبّل
😋=لذيذ
😛=لسان خارج
😜=غمزة مع لسان
🤪=وجه مجنون
😝=لسان وعينان مغمضتان
🤗=عناق
🤭=يغطي فمه بيده
🤫=صمت
🤔=تفكير
😐=وجه محايد
😑=وجه بلا تعبير
😶=وجه بلا فم
😏=ابتسامة ماكرة
😒=وجه غير مبالٍ
🙄=تدوير العينين
😬=وجه متوتر
😌=ارتياح
😔=حزين
😪=نعسان
😴=نائم
😷=كمامة
🤒=مريض
🤢=غثيان
🤮=تقيؤ
🥵=حرّ شديد
🥶=برد شديد
😵=دوار
🤯=ذهول
😎=نظارة شمسية
🤓=مهووس بالدراسة
🧐=وجه بعدسة
😕=حيرة
😟=قلق
🙁=عبوس خفيف
☹️=عبوس
😮=فم مفتوح
😯=دهشة
😲=ذهول
😳=خجل
🥺=عينان متوسلتان
😨=خوف
😰=قلق مع عرق
😥=حزن مع ارتياح
😢=بكاء
😭=بكاء شديد
😱=صراخ من الخوف
😖=وجه محتار
😣=وجه مجهد
😞=خيبة أمل
😓=عرق بارد
😩=وجه متعب
😫=وجه منهك
😤=غضب وزفير
😡=غاضب
😠=غضب
🤬=شتائم
😈=شيطان مبتسم
👿=شيطان غاضب
💀=جمجمة
☠️=جمجمة وعظمتان
💩=براز
🤡=مهرج
👻=شبح
👽=كائن فضائي
🤖=روبوت
🙈=قرد يغطي عينيه
🙉=قرد يغطي أذنيه
🙊=قرد يغطي فمه
🥳=وجه احتفال
🥲=ابتسامة مع دمعة
🤤=سيلان لعاب
🥱=تثاؤب
🫡=تحية
💋=قبلة
💌=رسالة حب
💘=قلب بسهم
💝=قلب بشريط
💖=قلب متلألئ
💗=قلب متنامٍ
💓=قلب نابض
💞=قلبان يدوران
💕=قلبان
💔=قلب مكسور
❤️=قلب أحمر
🧡=قلب برتقالي
💛=قلب أصفر
💚=قلب أخضر
💙=قلب أزرق
💜=قلب بنفسجي
🖤=قلب أسود
🤍=قلب أبيض
🤎=قلب بني
💯=مئة بالمئة
💢=غضب
💥=انفجار
💫=دوخة
💦=قطرات
💨=اندفاع
💬=فقاعة كلام
💭=فقاعة تفكير
💤=نوم
👋=تلويح
✋=يد مرفوعة
🖐️=كف مفتوحة
👌=موافق
✌️=علامة النصر
🤞=أصابع متقاطعة
🤟=أحبك بلغة الإشارة
🤘=قرون
🤙=اتصل بي
👈=إشارة لليسار
👉=إشارة لليمين
👆=إشارة للأعلى
👇=إشارة للأسفل
☝️=سبابة للأعلى
👍=إعجاب
👎=عدم إعجاب
✊=قبضة
👊=لكمة
👏=تصفيق
🙌=يدان مرفوعتان
👐=يدان مفتوحتان
🤲=كفّان للدعاء
🤝=مصافحة
🙏=دعاء أو شكر
✍️=كتابة
💪=عضلات
🫶=يدان بشكل قلب
👀=عينان
👁️=عين
👅=لسان
👄=فم
🧠=دماغ
👶=طفل رضيع
👦=ولد
👧=بنت
👨=رجل
👩=امرأة
🧔=رجل بلحية
👴=رجل مسن
👵=امرأة مسنة
👮=شرطي
👷=عامل بناء
🕵️=محقق
🎅=بابا نويل
👸=أميرة
🤴=أمير
🦸=بطل خارق
🧙=ساحر
🧛=مصاص دماء
🧜=حورية بحر
🧚=جنية
🏃=شخص يركض
💃=راقصة
🕺=راقص
🐶=كلب
🐱=قط
🐭=فأر
🐹=هامستر
🐰=أرنب
🦊=ثعلب
🐻=دب
🐼=باندا
🐨=كوالا
🐯=نمر
🦁=أسد
🐮=بقرة
🐷=خنزير
🐸=ضفدع
🐵=قرد
🐔=دجاجة
🐧=بطريق
🐦=طائر
🦆=بطة
🦅=نسر
🦉=بومة
🦇=خفاش
🐺=ذئب
🐴=حصان
🦄=حصان أحادي القرن
🐝=نحلة
🐛=يرقة
🦋=فراشة
🐌=حلزون
🐞=دعسوقة
🐜=نملة
🕷️=عنكبوت
🐢=سلحفاة
🐍=ثعبان
🦎=سحلية
🐙=أخطبوط
🦀=سلطعون
🐠=سمكة
🐟=سمكة
🐬=دلفين
🐳=حوت
🦈=قرش
🐊=تمساح
🐘=فيل
🦒=زرافة
🦓=حمار وحشي
🐪=جمل
🐫=جمل بسنامين
🐑=خروف
🐐=ماعز
🐕=كلب
🐈=قط
🕊️=حمامة
🌹=وردة
🌸=زهرة كرز
🌺=زهرة
🌻=دوار الشمس
🌷=توليب
🌱=شتلة
🌲=شجرة صنوبر
🌳=شجرة
🌴=نخلة
🌵=صبار
🍀=برسيم رباعي
🍁=ورقة قيقب
🍂=ورق متساقط
🌍=الكرة الأرضية
🌙=هلال
🌞=شمس بوجه
⭐=نجمة
🌟=نجمة متوهجة
✨=بريق
⚡=برق
🔥=نار
🌈=قوس قزح
☀️=شمس
⛅=غائم جزئياً
☁️=سحابة
🌧️=مطر
❄️=ثلج
☃️=رجل ثلج
🌊=موجة
💧=قطرة
🍎=تفاحة
🍊=برتقالة
🍋=ليمونة
🍌=موزة
🍉=بطيخ
🍇=عنب
🍓=فراولة
🍒=كرز
🍑=خوخ
🍍=أناناس
🥭=مانجو
🍅=طماطم
🥕=جزرة
🌽=ذرة
🥔=بطاطا
🍞=خبز
🧀=جبن
🍳=بيضة مقلية
🥞=فطائر
🍗=دجاج
🍔=برغر
🍟=بطاطس مقلية
🍕=بيتزا
🌮=تاكو
🍿=فشار
🍩=دونات
🍪=بسكويت
🎂=كعكة عيد ميلاد
🍰=قطعة كيك
🍫=شوكولاتة
🍬=حلوى
🍭=مصاصة
🍦=آيس كريم
☕=قهوة
🍵=شاي
🥤=مشروب
⚽=كرة قدم
🏀=كرة سلة
🎾=كرة تنس
🎮=يد ألعاب
🎯=هدف
🎲=نرد
🎵=نغمة
🎶=نغمات
🎤=ميكروفون
🎧=سماعات
🎁=هدية
🎉=احتفال
🎊=قصاصات ملونة
🏆=كأس
🥇=ميدالية ذهبية
🚗=سيارة
🚕=تاكسي
🚌=حافلة
🚑=سيارة إسعاف
🚓=سيارة شرطة
🚒=سيارة إطفاء
🚲=دراجة
🏍️=دراجة نارية
✈️=طائرة
🚀=صاروخ
🚂=قطار
🚢=سفينة
🏠=منزل
🏢=مبنى
🕌=مسجد
🕋=الكعبة
🏖️=شاطئ
⌚=ساعة يد
📱=هاتف
💻=حاسوب محمول
📷=كاميرا
📺=تلفاز
🔋=بطارية
💡=مصباح
📚=كتب
📖=كتاب مفتوح
✏️=قلم رصاص
📝=ملاحظة
📞=هاتف
📧=بريد
📌=دبوس
📎=مشبك
🔒=قفل
🔑=مفتاح
💰=كيس مال
💵=ورقة نقدية
💎=جوهرة
⏰=منبه
⏳=ساعة رملية
✅=علامة صح
❌=علامة خطأ
⭕=دائرة
❗=تعجب
❓=استفهام
‼️=تعجبان
⚠️=تحذير
🚫=ممنوع
🔔=جرس
🔕=جرس مكتوم
➕=زائد
➖=ناقص
✔️=علامة صح
💲=دولار
🆗=موافق
🆕=جديد
🔴=دائرة حمراء
🟢=دائرة خضراء
🔵=دائرة زرقاء
🟡=دائرة صفراء
⚫=دائرة سوداء
⚪=دائرة بيضاء
"""
}

/** Algerian wilayas (الولايات الجزائرية) for the letter game. */
object Wilayas {
    val all = listOf(
        "أدرار", "الشلف", "الأغواط", "أم البواقي", "باتنة", "بجاية", "بسكرة", "بشار", "البليدة", "البويرة",
        "تمنراست", "تبسة", "تلمسان", "تيارت", "تيزي وزو", "الجزائر", "الجلفة", "جيجل", "سطيف", "سعيدة",
        "سكيكدة", "سيدي بلعباس", "عنابة", "قالمة", "قسنطينة", "المدية", "مستغانم", "المسيلة", "معسكر", "ورقلة",
        "وهران", "البيض", "إليزي", "برج بوعريريج", "بومرداس", "الطارف", "تندوف", "تيسمسيلت", "الوادي", "خنشلة",
        "سوق أهراس", "تيبازة", "ميلة", "عين الدفلى", "النعامة", "عين تموشنت", "غرداية", "غليزان", "تميمون",
        "برج باجي مختار", "أولاد جلال", "بني عباس", "عين صالح", "عين قزام", "توقرت", "جانت", "المغير", "المنيعة"
    )

    fun number(name: String): Int = all.indexOf(name) + 1

    private fun firstLetter(name: String): Char {
        val n = if (name.startsWith("ال") && name.length > 2) name.substring(2) else name
        return GameData.normalize(n[0])
    }

    fun byLetter(c: Char): List<String> = all.filter { firstLetter(it) == c }
}
