package com.ndr.tools

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var statusTv: TextView

    private val bg = 0xFF0B0F1A.toInt()
    private val cardBg = 0xFF121827.toInt()
    private val border = 0xFF4A5BFF.toInt()
    private val blue = 0xFF4D8DFF.toInt()
    private val muted = 0xFF8C96A8.toInt()
    private val green = 0xFF2ED47A.toInt()
    private val red = 0xFFFF5C6C.toInt()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun round(fill: Int, r: Int, strokeColor: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = dp(r).toFloat()
        if (strokeColor != 0) g.setStroke(dp(1), strokeColor)
        return g
    }

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    private fun card(parent: LinearLayout, title: String): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = round(cardBg, 16, 0x663D5BFF)
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, 0, 0, dp(12))
        parent.addView(c, lp)
        val t = text(title, 16f, blue, true)
        t.setPadding(0, 0, 0, dp(8))
        c.addView(t)
        return c
    }

    private fun button(label: String, filled: Boolean, click: () -> Unit): TextView {
        val b = text(label, 14f, Color.WHITE, true)
        b.gravity = Gravity.CENTER
        b.setPadding(dp(12), dp(12), dp(12), dp(12))
        b.background = if (filled) round(0xFF3550E0.toInt(), 12, border) else round(0xFF1A2236.toInt(), 12, 0x663D5BFF)
        b.setOnClickListener { click() }
        return b
    }

    private fun gap(c: LinearLayout, h: Int = 8) {
        c.addView(View(this), LinearLayout.LayoutParams(1, dp(h)))
    }

    private fun serviceEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        val cn = ComponentName(this, FloatService::class.java)
        return s.split(':').any {
            it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs.get(this)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(24), dp(16), dp(24))
        scroll.addView(root)
        setContentView(scroll)

        val title = text("👑  NDR TOOLS", 24f, blue, true)
        title.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
        root.addView(title)
        val sub = text("أدوات عائمة تعمل فوق أي كيبورد • v1.0", 12f, muted)
        sub.setPadding(0, dp(2), 0, dp(16))
        root.addView(sub)

        // ---- service status
        val st = card(root, "حالة الخدمة")
        statusTv = text("", 15f, Color.WHITE, true)
        st.addView(statusTv)
        gap(st)
        st.addView(button("1) تفعيل الخدمة من إمكانية الوصول", true) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "اختر NDR TOOLS ثم فعّله", Toast.LENGTH_LONG).show()
        })
        gap(st)
        st.addView(text(
            "إن كان الزر مظلّلاً وظهرت رسالة «إعداد مقيّد» (أندرويد 13 فما فوق): افتح معلومات التطبيق ← " +
                "القائمة ⋮ في الأعلى ← «السماح بالإعدادات المقيّدة» ثم ارجع وفعّل الخدمة.",
            12f, muted
        ))
        gap(st)
        st.addView(button("معلومات التطبيق", false) {
            val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            i.data = Uri.parse("package:$packageName")
            startActivity(i)
        })

        // ---- options
        val op = card(root, "الخيارات")
        op.addView(switchRow("إظهار الفقاعة العائمة 👑", "bubble_on", true))
        op.addView(switchRow("اهتزاز خفيف عند الضغط", "haptic", true))

        // ---- saved values
        val vals = card(root, "القيم السريعة")
        vals.addView(text("تُدرَج بضغطة من القائمة العائمة. يمكنك أيضاً حفظها من الخانة مباشرة.", 12f, muted))
        gap(vals)
        vals.addView(valueField("🏆  رقم الكأس", "val_cup"))
        gap(vals)
        vals.addView(valueField("#  الروم ID", "val_room"))

        // ---- how to
        val how = card(root, "طريقة الاستخدام")
        how.addView(text(
            "• اضغط الفقاعة 👑 لفتح القائمة، واسحبها لتغيير مكانها.\n" +
                "• «الكتابة» مفتاح عام؛ فكك / نقط / عكس تعمل أثناء الكتابة بأي كيبورد.\n" +
                "• ضغطة مطوّلة على فكك أو نقط أو عكس تحوّل النص الموجود في الخانة مرة واحدة " +
                "(أو النص المحدّد فقط). زر التراجع يعيد النص السابق عند الحاجة.\n" +
                "• ولد / ولايات: اختر الأقسام ثم الحرف فتُدرج الكلمات في الخانة.\n" +
                "• تكبيس: اختر العدد والسرعة ثم حرّك الهدف 🎯 إلى المكان واضغط ابدأ.\n" +
                "• قارئ الإيموجي: ينطق اسم أي إيموجي تكتبه أو يصلك في إشعار.\n" +
                "• لا تعمل الفقاعة داخل خانات كلمات المرور حمايةً لخصوصيتك.",
            13f, Color.WHITE
        ))
    }

    override fun onResume() {
        super.onResume()
        val on = serviceEnabled()
        statusTv.text = if (on) "✅  الخدمة مفعّلة" else "❌  الخدمة غير مفعّلة"
        statusTv.setTextColor(if (on) green else red)
    }

    private fun switchRow(label: String, key: String, def: Boolean): View {
        val sw = Switch(this)
        sw.text = label
        sw.textSize = 14f
        sw.setTextColor(Color.WHITE)
        sw.isChecked = prefs.getBoolean(key, def)
        sw.setPadding(0, dp(6), 0, dp(6))
        sw.setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() }
        return sw
    }

    private fun valueField(label: String, key: String): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.addView(text(label, 13f, Color.WHITE, true))
        val et = EditText(this)
        et.setText(prefs.getString(key, "") ?: "")
        et.setTextColor(Color.WHITE)
        et.setHintTextColor(muted)
        et.hint = "اكتب القيمة"
        et.setSingleLine(true)
        et.background = round(0xFF0E1322.toInt(), 10, 0x663D5BFF)
        et.setPadding(dp(12), dp(10), dp(12), dp(10))
        et.layoutDirection = View.LAYOUT_DIRECTION_LTR
        et.setOnFocusChangeListener { _, focused ->
            if (!focused) {
                val v = et.text.toString().trim()
                if (v.isEmpty()) prefs.edit().remove(key).apply() else prefs.edit().putString(key, v).apply()
            }
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, dp(4), 0, 0)
        box.addView(et, lp)
        return box
    }

    override fun onPause() {
        super.onPause()
        currentFocus?.clearFocus()
    }
}
